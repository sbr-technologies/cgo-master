module Admin::WelcomeHelper
end
