class EmployerObserver < ActiveRecord::Observer

  def after_create(employer)
  end

end
