module Admin::ApplicantsHelper
end
