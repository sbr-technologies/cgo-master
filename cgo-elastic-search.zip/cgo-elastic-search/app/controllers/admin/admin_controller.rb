class Admin::AdminController < ApplicationController
end
