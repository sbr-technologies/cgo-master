module Admin::RegistrationsHelper
end
