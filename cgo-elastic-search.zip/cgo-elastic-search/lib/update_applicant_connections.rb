class UpdateApplicantConnections

  # Grab connections from linkedin 
  def perform 

  end

end
