module ApplicantHelper
end
