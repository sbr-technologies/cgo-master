class AuthsubToken < ActiveRecord::Base
end
