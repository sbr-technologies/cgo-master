class EmployerStat < ActiveRecord::Base
  belongs_to :employer
end
