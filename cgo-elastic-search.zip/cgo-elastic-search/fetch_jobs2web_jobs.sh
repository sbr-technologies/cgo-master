curl "http://feeds.jobs2web.com/feeds/view?siteId=190&feedId=895" > /mnt/ftp/rbradshaw@srcinc.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=319&feedId=888" > /mnt/ftp/abigail.whiffen@unisys.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=254&feedId=1351" > /mnt/ftp/ROMACKIE_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=297&feedId=1163" > /mnt/ftp/carla.reissner@capitalone.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=280&feedId=1586" > /mnt/ftp/JCopeland@successfactors.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=324&feedId=1858" > /mnt/ftp/nnguyen@successfactors.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=337&feedId=18900" > /mnt/ftp/stephanie.garrigus@shaker.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=643&feedId=37400" > /mnt/ftp/geerska@leidos.com_`date "+%Y%m%d"`.xml
curl "http://feeds.jobs2web.com/feeds/view?siteId=518&feedId=47900" > /mnt/ftp/Roy.Cook@roberthalf.com_`date "+%Y%m%d"`.xml
 
