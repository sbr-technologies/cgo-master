class RecruiterStat < ActiveRecord::Base
  belongs_to :recruiter
end
