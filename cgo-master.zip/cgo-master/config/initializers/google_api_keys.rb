GOOGLE_API_KEY = YAML.load(File.read(RAILS_ROOT + "/config/google_api_keys.yml"));
