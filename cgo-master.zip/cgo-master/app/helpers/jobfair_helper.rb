module JobfairHelper
end
