curl "http://feeds.jobs2web.com/feeds/view?siteId=643&feedId=37400" > /mnt/ftp/geerska@leidos.com_`date "+%Y%m%d"`.xml
