# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cgray::Application.config.secret_token = '5a40e662c9bb31bc1a78e7462c77c2d5bc62dc6a802e92786272b0081f31af3f83826f93c1df33c55e3fbc5781e10045a30cd94b83ffda51b1c75144ff43e6de'
